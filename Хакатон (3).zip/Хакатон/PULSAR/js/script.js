
// ==================================================
// PULSAR — CREW DASHBOARD
// ==================================================


// ==================================================
// ДЕМОНСТРАЦІЙНІ ДАНІ
// ==================================================

const astronauts = [

    {
        id: 1,
        name: "Emily Carter",
        role: "Flight Engineer",
        status: "Normal",
        pulse: 76,
        oxygen: 98,
        temperature: 33.8,
        battery: 87,
        connected: true,
        warning: "No active warnings",

        pulseHistory: [
            72, 75, 73, 78, 74,
            79, 75, 77, 74, 76
        ]
    },

    {
        id: 2,
        name: "James Miller",
        role: "Commander",
        status: "Normal",
        pulse: 72,
        oxygen: 97,
        temperature: 34.1,
        battery: 92,
        connected: true,
        warning: "No active warnings",

        pulseHistory: [
            70, 72, 71, 75, 73,
            70, 74, 71, 73, 72
        ]
    },

    {
        id: 3,
        name: "Sarah Wilson",
        role: "Researcher",
        status: "Warning",
        pulse: 110,
        oxygen: 96,
        temperature: 34.5,
        battery: 74,
        connected: true,
        warning: "Simulated heart rate warning",

        pulseHistory: [
            78, 82, 86, 91, 89,
            98, 96, 105, 102, 110
        ]
    },

    {
        id: 4,
        name: "Daniel Brown",
        role: "Pilot",
        status: "Critical",
        pulse: 132,
        oxygen: 85,
        temperature: 33.9,
        battery: 65,
        connected: true,
        warning: "Simulated critical alert",

        pulseHistory: [
            88, 94, 92, 108, 104,
            124, 119, 136, 129, 132
        ]
    }

];


// ==================================================
// ДЕМОНСТРАЦІЙНЕ СХОВИЩЕ
// ==================================================

const STORAGE_KEY = "pulsar_demo_crew";


// Початкова історія пульсу

const demoPulseProfiles = new Map(

    astronauts.map(person => [

        person.id,

        {
            name: person.name,
            pulse: person.pulse,
            history: person.pulseHistory
        }

    ])

);


// ==================================================
// ВІДНОВЛЕННЯ ІСТОРІЇ ПУЛЬСУ
// ==================================================

function restorePulseHistory(person) {

    if (person.pulseHistory !== undefined) {
        return person;
    }

    const demo = demoPulseProfiles.get(person.id);

    const matchesDemo =
        demo &&
        demo.name === person.name &&
        demo.pulse === person.pulse;

    return {

        ...person,

        pulseHistory: matchesDemo
            ? [...demo.history]
            : []

    };

}


// ==================================================
// ВІДНОВЛЕННЯ ДАНИХ ЗІ СХОВИЩА
// ==================================================

function restoreCrew() {

    try {

        const savedCrew =
            sessionStorage.getItem(STORAGE_KEY);

        if (savedCrew) {

            const parsedCrew = JSON.parse(savedCrew);

            if (Array.isArray(parsedCrew)) {

                astronauts.splice(

                    0,

                    astronauts.length,

                    ...parsedCrew.map(restorePulseHistory)

                );

            }

        }

    } catch (error) {

        console.error(
            "Cannot load demo crew:",
            error
        );

    }

}


// Початкове відновлення даних

restoreCrew();


// ==================================================
// ЗБЕРЕЖЕННЯ ДАНИХ
// ==================================================

function saveCrew() {

    try {

        sessionStorage.setItem(

            STORAGE_KEY,

            JSON.stringify(astronauts)

        );

        // ==========================================
        // NOTIFICATION CENTER
        // Повідомляємо про оновлення даних екіпажу
        // ==========================================

        document.dispatchEvent(

            new CustomEvent(

                "pulsar:crew-change",

                {

                    detail: {

                        crew: astronauts

                    }

                }

            )

        );

        return true;

    } catch (error) {

        console.error(
            "Cannot save demo crew:",
            error
        );

        return false;

    }

}


// ==================================================
// ПРІОРИТЕТИ СТАТУСІВ
// ==================================================

const priority = {

    Critical: 0,
    Warning: 1,
    Pending: 2,
    Normal: 3

};

let currentFilter = "All";


// ==================================================
// HTML-ЕЛЕМЕНТИ
// ==================================================

const crewGrid =
    document.getElementById("crew-grid");

const searchInput =
    document.getElementById("search");

const visibleCount =
    document.getElementById("visible-count");


// ==================================================
// ЕЛЕМЕНТИ ВЕРХНЬОЇ ПАНЕЛІ
// ==================================================

const menuToggle =
    document.getElementById("menu-toggle");

const crewMenu =
    document.getElementById("crew-menu");

const searchToggle =
    document.getElementById("search-toggle");

const searchPanel =
    document.getElementById("search-panel");

const searchClose =
    document.getElementById("search-close");


// ==================================================
// ЗАХИСТ ТЕКСТОВИХ ДАНИХ
// ==================================================

function escapeHTML(value) {

    return String(value ?? "—")

        .replaceAll("&", "&amp;")

        .replaceAll("<", "&lt;")

        .replaceAll(">", "&gt;")

        .replaceAll('"', "&quot;")

        .replaceAll("'", "&#39;");

}


// ==================================================
// ОНОВЛЕННЯ СТАТИСТИКИ
// ==================================================

function updateStatistics() {

    // Загальна кількість астронавтів

    document.getElementById("total-count")
        .textContent = astronauts.length;


    // Критичний стан

    document.getElementById("critical-count")
        .textContent = astronauts.filter(

            person => person.status === "Critical"

        ).length;


    // Попередження

    document.getElementById("warning-count")
        .textContent = astronauts.filter(

            person => person.status === "Warning"

        ).length;


    // Очікування даних

    document.getElementById("pending-count")
        .textContent = astronauts.filter(

            person => person.status === "Pending"

        ).length;


    // Нормальний стан

    document.getElementById("normal-count")
        .textContent = astronauts.filter(

            person => person.status === "Normal"

        ).length;

}


// ==================================================
// ГРАФІК ПУЛЬСУ
// ==================================================

function createPulseChart(person) {

    const values = Array.isArray(person.pulseHistory)

        ? person.pulseHistory.slice(-10)

        : [];


    // Колір графіка залежно від статусу

    const statusClass = Object.hasOwn(
        priority,
        person.status
    )

        ? person.status.toLowerCase()

        : "pending";


    // ==============================================
    // ЯКЩО ІСТОРІЯ ВІДСУТНЯ
    // ==============================================

    if (

        values.length < 2 ||

        !values.every(Number.isFinite)

    ) {

        return `

            <div class="pulse-chart-container
                ${statusClass}">

                <div class="pulse-chart-header">

                    <span class="pulse-chart-title">

                        Heart Rate Trend

                    </span>

                </div>

                <div class="pulse-chart-empty">

                    No pulse history available

                </div>

            </div>

        `;

    }


    // ==============================================
    // РОЗМІРИ ГРАФІКА
    // ==============================================

    const width = 400;
    const height = 95;

    const left = 35;
    const right = 8;
    const top = 8;
    const bottom = 10;


    // Межі показників

    const min = Math.min(...values) - 5;

    const max = Math.max(...values) + 5;

    const range = max - min;


    // ==============================================
    // КООРДИНАТИ ТОЧОК
    // ==============================================

    const points = values.map((value, index) => ({

        x: left +

            index / (values.length - 1) *

            (width - left - right),

        y: height - bottom -

            (value - min) / range *

            (height - top - bottom)

    }));


    // Формування лінії графіка

    const linePoints = points

        .map(point => `${point.x},${point.y}`)

        .join(" ");


    // Остання точка

    const last = points[points.length - 1];


    // ==============================================
    // ГОРИЗОНТАЛЬНА СІТКА
    // ==============================================

    let grid = "";

    for (let i = 0; i <= 3; i++) {

        const y = top +

            i / 3 * (height - top - bottom);

        const label = Math.round(

            max - i / 3 * range

        );

        grid += `

            <line
                class="pulse-chart-grid"
                x1="${left}"
                y1="${y}"
                x2="${width - right}"
                y2="${y}"
                stroke-width="1"
                stroke-dasharray="4 4"
            />

            <text
                x="${left - 8}"
                y="${y + 4}"
                text-anchor="end"
                font-size="10"
                fill="#91a5bd">

                ${label}

            </text>

        `;

    }


    // ==============================================
    // ГОТОВИЙ ГРАФІК
    // ==============================================

    return `

        <div class="pulse-chart-container
            ${statusClass}">

            <div class="pulse-chart-header">

                <span class="pulse-chart-title">

                    ♡ Heart Rate Trend (bpm)

                </span>

                <span class="pulse-chart-period">

                    Last ${values.length} samples · Demo

                </span>

            </div>


            <svg
                class="pulse-chart"
                viewBox="0 0 ${width} ${height}"
                preserveAspectRatio="none"
                role="img"
                aria-label="Demo heart rate history">

                ${grid}

                <polyline
                    class="pulse-line"
                    points="${linePoints}"
                    fill="none"
                    stroke-width="2.5"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    vector-effect="non-scaling-stroke"
                />

                <circle
                    class="pulse-point"
                    cx="${last.x}"
                    cy="${last.y}"
                    r="3.5"
                />

            </svg>


            <div class="pulse-chart-labels">

                <span>Earlier</span>

                <span>Latest</span>

            </div>

        </div>

    `;

}


// ==================================================
// СТВОРЕННЯ КАРТКИ АСТРОНАВТА
// ==================================================

function createAstronautCard(person) {

    const statusClass = Object.hasOwn(
        priority,
        person.status
    )

        ? person.status.toLowerCase()

        : "pending";


    // ==============================================
    // ІНІЦІАЛИ АСТРОНАВТА
    // ==============================================

    const initials = person.name

        .trim()

        .split(/\s+/)

        .slice(0, 2)

        .map(word => word[0])

        .join("");


    // Створення картки

    const card = document.createElement("article");

    card.className =
        `astronaut-card ${statusClass}`;


    // ==============================================
    // ПЕРЕВІРКА АКТИВНОГО SOS
    // ==============================================

    const sosActive = isSosActive(person.id);

    card.classList.toggle(

        "sos-active",

        sosActive

    );


    // ==============================================
    // ВМІСТ КАРТКИ АСТРОНАВТА
    // ==============================================

    card.innerHTML = `


        <!-- ІНФОРМАЦІЯ ПРО АСТРОНАВТА -->

        <div class="astronaut-header">

            <div class="avatar">

                ${escapeHTML(initials)}

            </div>

            <div class="astronaut-info">

                <h3>

                    ${escapeHTML(person.name)}

                </h3>

                <p>

                    ${escapeHTML(person.role)}

                </p>

            </div>

            <span class="status ${statusClass}">

                ● ${escapeHTML(person.status)}

            </span>

        </div>


        <!-- ======================================
             ОСНОВНІ ПОКАЗНИКИ
        ======================================= -->

        <div class="metrics">


            <!-- ПУЛЬС -->

            <div class="metric">

                <span class="metric-name">

                    Heart Rate

                </span>

                <span class="metric-value">

                    ${escapeHTML(person.pulse ?? "—")}

                </span>

                <span class="metric-unit">

                    bpm

                </span>

            </div>


            <!-- НАСИЧЕННЯ КРОВІ КИСНЕМ -->

            <div class="metric">

                <span class="metric-name">

                    SpO₂

                </span>

                <span class="metric-value">

                    ${escapeHTML(person.oxygen ?? "—")}

                </span>

                <span class="metric-unit">

                    %

                </span>

            </div>


            <!-- ТЕМПЕРАТУРА ШКІРИ -->

            <div class="metric">

                <span class="metric-name">

                    Skin Temperature

                </span>

                <span class="metric-value">

                    ${escapeHTML(person.temperature ?? "—")}

                </span>

                <span class="metric-unit">

                    °C

                </span>

            </div>

        </div>


        <!-- ======================================
             ГРАФІК ПУЛЬСУ
        ======================================= -->

        ${createPulseChart(person)}


        <!-- ======================================
             ПОПЕРЕДЖЕННЯ
        ======================================= -->

        <div class="alert-message ${statusClass}">

            ${escapeHTML(person.warning)}

        </div>


        <!-- ======================================
             АКТИВНИЙ SOS
        ======================================= -->

        ${sosActive ? `

            <div class="sos-active-banner">

                ⚠ SOS Activated — Simulation

            </div>

        ` : ""}


        <!-- ======================================
             СТАН ПРИСТРОЮ
        ======================================= -->

        <div class="device-info">

            <span class="${person.connected
                ? "connected"
                : ""}">

                ● ${person.connected

                    ? "Connected"

                    : "No device"}

            </span>

            <span>

                Battery:

                ${person.battery == null

                    ? "—"

                    : escapeHTML(person.battery) + "%"}

            </span>

        </div>


        <!-- ======================================
             КНОПКИ КАРТКИ
        ======================================= -->

        <div class="card-actions">

            <button class="details-button">

                View Details →

            </button>

            <button class="sos-button
                ${sosActive ? "is-active" : ""}">

                ${sosActive

                    ? "SOS Active (Demo)"

                    : "SOS / Emergency"}

            </button>

        </div>

    `;


    // ==============================================
    // КНОПКА VIEW DETAILS
    // ==============================================

    card.querySelector(".details-button")

        .addEventListener("click", function () {

            openAstronaut(person.id);

        });


    // ==============================================
    // КНОПКА SOS
    // ==============================================

    card.querySelector(".sos-button")

        .addEventListener("click", function () {

            openEmergency(person.id);

        });


    // ==============================================
    // НАТИСКАННЯ НА ВСЮ КАРТКУ
    // ==============================================

    card.style.cursor = "pointer";

    card.addEventListener("click", function (event) {

        if (event.target.closest("button")) {

            return;

        }

        openAstronaut(person.id);

    });

    return card;

}


// ==================================================
// ВІДОБРАЖЕННЯ АСТРОНАВТІВ
// ==================================================

function renderAstronauts() {

    // Поточний пошуковий запит

    const search = searchInput.value

        .toLowerCase()

        .trim();


    // ==============================================
    // ФІЛЬТРАЦІЯ АСТРОНАВТІВ
    // ==============================================

    const filteredAstronauts = astronauts.filter(person => {

        const matchesStatus =

            currentFilter === "All" ||

            person.status === currentFilter;

        const matchesSearch =

            person.name.toLowerCase().includes(search);

        return matchesStatus && matchesSearch;

    });


    // ==============================================
    // СОРТУВАННЯ ЗА КРИТИЧНІСТЮ
    // ==============================================

    filteredAstronauts.sort((a, b) => {

        return (priority[a.status] ?? 2) -

               (priority[b.status] ?? 2);

    });


    // Очищення попередніх карток

    crewGrid.innerHTML = "";


    // ==============================================
    // АДАПТИВНЕ РОЗТАШУВАННЯ КАРТОК
    // ==============================================

    // Кількість видимих астронавтів

    const count = filteredAstronauts.length;

    let columns;


    // Один або два астронавти

    if (count <= 2) {

        columns = Math.max(1, count);

    }


    // Три або чотири астронавти

    else if (count <= 4) {

        columns = 2;

    }


    // П'ять або шість астронавтів

    else if (count <= 6) {

        columns = 3;

    }


    // Сім і більше астронавтів

    else {

        columns = 4;

    }


    // Передаємо кількість стовпчиків у CSS

    crewGrid.style.setProperty(

        "--crew-columns",

        columns

    );


    // Компактний режим від п'яти астронавтів

    crewGrid.classList.toggle(

        "compact",

        count > 4

    );


    // Максимально компактний режим від семи

    crewGrid.classList.toggle(

        "extra-compact",

        count > 6

    );


    // ==============================================
    // СТВОРЕННЯ КАРТОК
    // ==============================================

    filteredAstronauts.forEach(person => {

        crewGrid.appendChild(

            createAstronautCard(person)

        );

    });


    // Кількість видимих астронавтів

    visibleCount.textContent =

        `${filteredAstronauts.length} astronauts`;


    // ==============================================
    // ЯКЩО НІКОГО НЕ ЗНАЙДЕНО
    // ==============================================

    if (filteredAstronauts.length === 0) {

        crewGrid.innerHTML = `

            <p class="empty-message">

                No astronauts found

            </p>

        `;

    }


    // ==============================================
    // ОНОВЛЕННЯ СТАТИСТИКИ
    // ==============================================

    updateStatistics();


    // ==============================================
    // ЗБЕРЕЖЕННЯ ДАНИХ
    // ==============================================

    // saveCrew() також повідомляє Notification Center
    // про актуальний стан усього екіпажу.

    saveCrew();

}


// ==================================================
// ВИПАДАЮЧЕ МЕНЮ СТАТИСТИКИ
// ==================================================


// Закриття меню

function closeCrewMenu() {

    crewMenu.hidden = true;

    menuToggle.classList.remove("active");

    menuToggle.setAttribute(

        "aria-expanded",

        "false"

    );

}


// Відкриття меню

function openCrewMenu() {

    // Закриваємо центр сповіщень

    window.PulsarNotifications?.closePanel();


    // Закриваємо пошук

    closeCrewSearch();


    // Відкриваємо статистику

    crewMenu.hidden = false;

    menuToggle.classList.add("active");

    menuToggle.setAttribute(

        "aria-expanded",

        "true"

    );

}


// ==================================================
// НАТИСКАННЯ НА ТРИ РИСОЧКИ
// ==================================================

menuToggle.addEventListener("click", function () {

    if (crewMenu.hidden) {

        openCrewMenu();

    } else {

        closeCrewMenu();

    }

});


// ==================================================
// ЗАКРИТТЯ ПРИ НАТИСКАННІ ПОЗА МЕНЮ
// ==================================================

document.addEventListener("click", function (event) {

    if (

        !crewMenu.contains(event.target) &&

        !menuToggle.contains(event.target)

    ) {

        closeCrewMenu();

    }

});


// ==================================================
// КОМПАКТНИЙ ПОШУК
// ==================================================


// Відкриття поля пошуку

function openCrewSearch() {

    // Закриваємо центр сповіщень

    window.PulsarNotifications?.closePanel();


    // Закриваємо меню статистики

    closeCrewMenu();


    // Відкриваємо пошук

    searchPanel.hidden = false;

    searchToggle.classList.add("active");

    searchToggle.setAttribute(

        "aria-expanded",

        "true"

    );

    searchInput.focus();

}


// Закриття поля пошуку

function closeCrewSearch() {

    searchPanel.hidden = true;

    searchToggle.classList.remove("active");

    searchToggle.setAttribute(

        "aria-expanded",

        "false"

    );


    // Очищення пошукового запиту

    if (searchInput.value !== "") {

        searchInput.value = "";

        renderAstronauts();

    }

}


// ==================================================
// НАТИСКАННЯ НА ЛУПУ
// ==================================================

searchToggle.addEventListener("click", function () {

    if (searchPanel.hidden) {

        openCrewSearch();

    } else {

        closeCrewSearch();

    }

});


// ==================================================
// НАТИСКАННЯ НА ХРЕСТИК ПОШУКУ
// ==================================================

searchClose.addEventListener("click", function () {

    closeCrewSearch();

    searchToggle.focus();

});


// ==================================================
// ПОШУК ПІД ЧАС ВВЕДЕННЯ ТЕКСТУ
// ==================================================

searchInput.addEventListener(

    "input",

    renderAstronauts

);


// ==================================================
// ФІЛЬТРАЦІЯ АСТРОНАВТІВ
// ==================================================

document.querySelectorAll("[data-filter]")

    .forEach(button => {

        button.addEventListener("click", function () {

            // Зберігаємо вибраний фільтр

            currentFilter = button.dataset.filter;


            // Виділення активного фільтра

            document.querySelectorAll(".filter-button")

                .forEach(filterButton => {

                    const isActive =

                        filterButton.dataset.filter ===

                        currentFilter;

                    filterButton.classList.toggle(

                        "active",

                        isActive

                    );

                    filterButton.setAttribute(

                        "aria-pressed",

                        String(isActive)

                    );

                });


            // Оновлення карток

            renderAstronauts();


            // Закриття випадаючого меню

            closeCrewMenu();

            menuToggle.focus();

        });

    });


// ==================================================
// ЗАКРИТТЯ МЕНЮ ТА ПОШУКУ
// ЗА ДОПОМОГОЮ ESCAPE
// ==================================================

document.addEventListener("keydown", function (event) {

    if (event.key !== "Escape") {

        return;

    }


    // Не втручаємося в роботу модальних вікон

    if (document.querySelector("dialog[open]")) {

        return;

    }


    // Закриття випадаючого меню

    if (!crewMenu.hidden) {

        closeCrewMenu();

        menuToggle.focus();

        return;

    }


    // Закриття пошуку

    if (!searchPanel.hidden) {

        closeCrewSearch();

        searchToggle.focus();

    }

});


// ==================================================
// ДЕТАЛЬНА ІНФОРМАЦІЯ ПРО АСТРОНАВТА
// ==================================================

function openAstronaut(id) {

    // Зберігаємо актуальні дані

    if (!saveCrew()) {

        alert("Demo storage is unavailable.");

        return;

    }


    // Перехід до індивідуальної панелі

    window.location.href =

        `pages/astronaut.html?id=${encodeURIComponent(id)}`;

}


// ==================================================
// SOS — ЕКСТРЕНА ДОПОМОГА
// ==================================================

function openEmergency(id) {

    const person = astronauts.find(

        astronaut => astronaut.id === id

    );

    if (person) {

        openSosDialog(person);

    }

}


// ==================================================
// ПОЧАТКОВИЙ ЗАПУСК
// ==================================================


// Початковий стан верхньої панелі

closeCrewMenu();

closeCrewSearch();


// Початковий стан фільтрів

document.querySelectorAll(".filter-button")

    .forEach(button => {

        const isActive =

            button.dataset.filter === currentFilter;

        button.classList.toggle(

            "active",

            isActive

        );

        button.setAttribute(

            "aria-pressed",

            String(isActive)

        );

    });


// Початкове відображення всіх астронавтів

renderAstronauts();


// ==================================================
// ВІДНОВЛЕННЯ ДАНИХ ПІСЛЯ ПОВЕРНЕННЯ
// З ІНДИВІДУАЛЬНОГО ПРОФІЛЮ
// ==================================================

window.addEventListener("pageshow", function () {

    // Отримуємо актуальні дані зі сховища

    restoreCrew();


    // Оновлюємо картки та центр сповіщень

    renderAstronauts();

});


// ==================================================
// ОНОВЛЕННЯ ПІСЛЯ АКТИВАЦІЇ АБО СКАСУВАННЯ SOS
// ==================================================

document.addEventListener(

    "pulsar:sos-change",

    renderAstronauts

);


// ==================================================
// ОНОВЛЕННЯ ДАНИХ ЕКІПАЖУ
// ДЛЯ МАЙБУТНЬОЇ ІНТЕГРАЦІЇ ІЗ СЕРВЕРОМ
// ==================================================

function updateCrewData(updates) {

    // Перевірка формату отриманих даних

    if (!Array.isArray(updates)) {

        return false;

    }


    // Оновлення даних кожного астронавта

    updates.forEach(update => {

        if (!update || typeof update !== "object") {

            return;

        }


        // Знаходимо відповідного астронавта

        const person = astronauts.find(

            item => item.id === update.id

        );

        if (!person) {

            return;

        }


        // ==========================================
        // ПОКАЗНИКИ, ЯКІ МОЖНА ОНОВЛЮВАТИ
        // ==========================================

        const keys = [

            // Статус здоров'я

            "status",

            "warning",


            // Основні фізичні показники

            "pulse",

            "oxygen",

            "temperature",

            "mass",

            "gripStrength",

            "gripHand",

            "restingHeartRate",


            // Стан пристрою

            "battery",

            "connected",


            // Історія вимірювань

            "pulseHistory",

            "history",

            "alertHistory",


            // Рухова активність

            "acceleration",

            "movement",

            "activity",


            // Самопочуття

            "sleepDuration",

            "sleepQuality",

            "stressLevel",


            // Навколишнє середовище

            "pressure",

            "airTemperature",

            "airOxygen",

            "airQuality",

            "co2",


            // Радіація

            "radiation",

            "radiationDose"

        ];


        // Оновлюємо лише передані показники

        keys.forEach(key => {

            if (Object.hasOwn(update, key)) {

                person[key] = update[key];

            }

        });

    });


    // Оновлюємо головну сторінку.
    // renderAstronauts() викликає saveCrew(),
    // а saveCrew() повідомляє Notification Center.

    renderAstronauts();

    return true;

}


// ==================================================
// ПІДКЛЮЧЕННЯ ДО ІНШИХ МОДУЛІВ
// ==================================================

window.PulsarCrew = Object.freeze({

    updateCrewData

});
