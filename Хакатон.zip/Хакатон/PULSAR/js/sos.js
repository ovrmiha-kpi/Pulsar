// ==============================
// PULSAR — SOS SYSTEM
// ==============================

// Демонстраційний режим
const SOS_DEMO_MODE = true;

const SOS_STORAGE_KEY = "pulsar_demo_sos";


// ==============================
// ОТРИМАННЯ СТАНІВ SOS
// ==============================

function getSosRecords() {

    const records = JSON.parse(
        sessionStorage.getItem(SOS_STORAGE_KEY) || "{}"
    );

    return records &&
        typeof records === "object" &&
        !Array.isArray(records)
        ? records
        : {};

}


// Перевірка активного SOS

function isSosActive(id) {

    try {

        return getSosRecords()[String(id)]?.active === true;

    } catch (error) {

        console.error("Cannot read SOS state:", error);

        return false;

    }

}


// Збереження стану SOS

function saveSosRecord(id, record) {

    const records = getSosRecords();

    records[String(id)] = record;

    sessionStorage.setItem(
        SOS_STORAGE_KEY,
        JSON.stringify(records)
    );

}


// Безпечне відображення тексту

function escapeSosText(value) {

    return String(value ?? "—")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#39;");

}


// ==============================
// АКТИВАЦІЯ SOS
// ==============================

async function activateSos(person) {

    if (!SOS_DEMO_MODE) {

        throw new Error("SOS API is not connected.");

    }

    // Захист від повторної активації

    if (isSosActive(person.id)) {

        return;

    }


    // Тут у майбутньому підключимо API сервера.
    // Поки що сигнал зберігається локально.

    saveSosRecord(person.id, {

        active: true,

        timestamp: new Date().toISOString(),

        mode: "demo"

    });

}


// ==============================
// СКИДАННЯ СИМУЛЯЦІЇ
// ==============================

function resetDemoSos(id) {

    if (!SOS_DEMO_MODE) {

        return;

    }

    const records = getSosRecords();

    delete records[String(id)];

    sessionStorage.setItem(
        SOS_STORAGE_KEY,
        JSON.stringify(records)
    );

}


// ==============================
// ОНОВЛЕННЯ ІНТЕРФЕЙСУ
// ==============================

function notifySosChange(id) {

    document.dispatchEvent(

        new CustomEvent("pulsar:sos-change", {

            detail: {
                astronautId: id
            }

        })

    );

}


// ==============================
// МОДАЛЬНЕ ВІКНО SOS
// ==============================

function openSosDialog(person) {

    if (!person || document.getElementById("sos-modal")) {

        return;

    }


    // Створення модального вікна

    const dialog = document.createElement("dialog");

    dialog.id = "sos-modal";

    dialog.className = "sos-modal";

    dialog.setAttribute(
        "aria-labelledby",
        "sos-modal-title"
    );

    const active = isSosActive(person.id);


    // Вміст вікна

    dialog.innerHTML = `

        <div class="sos-modal-content">

            <div class="sos-modal-header">

                <span class="sos-modal-icon">⚠</span>

                <h2 id="sos-modal-title">

                    ${active
                        ? "SOS Active"
                        : "Activate SOS?"}

                </h2>

                <button type="button"
                        class="sos-modal-close"
                        aria-label="Close">

                    &times;

                </button>

            </div>


            <!-- Інформація про астронавта -->

            <div class="sos-person">

                <strong>
                    ${escapeSosText(person.name)}
                </strong>

                <span>

                    ${escapeSosText(person.role)}

                    · AST-${escapeSosText(
                        String(person.id).padStart(3, "0")
                    )}

                </span>

            </div>


            <!-- Опис -->

            <p class="sos-modal-description">

                ${active
                    ? "An SOS simulation is already active for this astronaut."
                    : "Confirm to request emergency assistance for this astronaut."}

            </p>


            <!-- Одержувачі сигналу -->

            <div class="sos-recipient-info">

                <span>◎</span>

                <div>

                    <strong>Crew-wide alert</strong>

                    <p>

                        Intended recipients:
                        all other connected crew bracelets.

                    </p>

                </div>

            </div>


            <!-- Демонстраційний режим -->

            <div class="sos-demo-notice">

                DEMO MODE

                <p>

                    No real emergency notifications
                    will be sent.

                </p>

            </div>


            <!-- Результат -->

            <p id="sos-result"
               class="sos-result"
               role="status">
            </p>


            <!-- Кнопки -->

            <div class="sos-modal-actions">

                <button type="button"
                        class="sos-cancel-button">

                    ${active ? "Close" : "Cancel"}

                </button>


                ${active ? `

                    <button type="button"
                            class="sos-reset-button">

                        Reset Simulation

                    </button>

                ` : `

                    <button type="button"
                            class="sos-confirm-button">

                        Confirm SOS

                    </button>

                `}

            </div>

        </div>

    `;


    document.body.appendChild(dialog);


    // ==============================
    // HTML-ЕЛЕМЕНТИ
    // ==============================

    const result =
        dialog.querySelector("#sos-result");

    const confirm =
        dialog.querySelector(".sos-confirm-button");

    const cancel =
        dialog.querySelector(".sos-cancel-button");

    const close =
        dialog.querySelector(".sos-modal-close");

    const reset =
        dialog.querySelector(".sos-reset-button");

    let processing = false;


    // ==============================
    // ЗАКРИТТЯ ВІКНА
    // ==============================

    function closeDialog() {

        if (!processing) {

            dialog.close();

        }

    }

    cancel.addEventListener("click", closeDialog);

    close.addEventListener("click", closeDialog);

    dialog.addEventListener("click", event => {

        if (event.target === dialog) {

            closeDialog();

        }

    });

    dialog.addEventListener("cancel", event => {

        if (processing) {

            event.preventDefault();

        }

    });

    dialog.addEventListener("close", () => {

        dialog.remove();

    });


    // ==============================
    // ПІДТВЕРДЖЕННЯ SOS
    // ==============================

    if (confirm) {

        confirm.addEventListener("click", async () => {

            if (processing || isSosActive(person.id)) {

                return;

            }

            processing = true;

            confirm.disabled = true;
            cancel.disabled = true;
            close.disabled = true;

            confirm.textContent = "Activating...";

            result.textContent = "Processing SOS request...";


            try {

                await activateSos(person);

                result.className = "sos-result success";

                result.textContent =
                    "SOS activated in simulation. " +
                    "No real notifications sent.";


                dialog.querySelector("#sos-modal-title")
                    .textContent = "SOS Activated";

                confirm.textContent = "SOS Active";

                cancel.textContent = "Close";

                notifySosChange(person.id);

            } catch (error) {

                console.error("SOS activation error:", error);

                result.className = "sos-result error";

                result.textContent =
                    "Unable to activate SOS simulation. " +
                    "Please try again.";

                confirm.textContent = "Retry SOS";

                confirm.disabled = false;

            } finally {

                processing = false;

                cancel.disabled = false;

                close.disabled = false;

            }

        });

    }


    // ==============================
    // СКИДАННЯ SOS
    // ==============================

    if (reset) {

        reset.addEventListener("click", () => {

            try {

                resetDemoSos(person.id);

                notifySosChange(person.id);

                dialog.close();

            } catch (error) {

                result.className = "sos-result error";

                result.textContent =
                    "Unable to reset SOS simulation.";

            }

        });

    }


    dialog.showModal();

}