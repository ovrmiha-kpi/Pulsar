
// ==================================================
// PULSAR — NOTIFICATION CENTER
// ЄДИНИЙ ЦЕНТР СПОВІЩЕНЬ ЕКІПАЖУ
// ==================================================

(function () {

    "use strict";


    // ==============================================
    // 1. НАЛАШТУВАННЯ
    // ==============================================

    const STORAGE_KEY = "pulsar_demo_notifications";

    const CREW_STORAGE_KEY = "pulsar_demo_crew";

    const SOS_STORAGE_KEY = "pulsar_demo_sos";


    // Демонстраційний поріг заряду браслета

    const LOW_BATTERY_THRESHOLD = 20;


    // Періодичність перевірки відкритої сторінки

    const CHECK_INTERVAL = 60000;


    // Пріоритети сповіщень

    const priorities = {

        critical: 0,

        warning: 1,

        device: 2,

        reminder: 3,

        info: 4

    };


    // Допустимі розділи профілю

    const validSections = [

        "health",

        "environment",

        "analytics",

        "insights",

        "guide",

        "settings"

    ];


    // Поточний фільтр

    let currentFilter = "all";

    let uiInitialized = false;

    let storageError = false;


    // ==============================================
    // 2. ДОПОМІЖНІ ФУНКЦІЇ
    // ==============================================

    function escapeHTML(value) {

        return String(value ?? "—")

            .replaceAll("&", "&amp;")

            .replaceAll("<", "&lt;")

            .replaceAll(">", "&gt;")

            .replaceAll('"', "&quot;")

            .replaceAll("'", "&#39;");

    }


    // Створення унікального ID

    function createId() {

        if (typeof window.crypto?.randomUUID === "function") {

            return window.crypto.randomUUID();

        }

        return Date.now().toString(36) +

            "-" +

            Math.random().toString(36).slice(2);

    }


    // Безпечне отримання даних зі сховища

    function readStorage(key, fallback) {

        try {

            const value = sessionStorage.getItem(key);

            return value ? JSON.parse(value) : fallback;

        } catch (error) {

            console.error(

                "Cannot read demo storage:",

                error

            );

            return fallback;

        }

    }


    // Поточна локальна дата

    function localDate(value = new Date()) {

        const date = value instanceof Date

            ? value

            : new Date(value);

        if (!Number.isFinite(date.getTime())) {

            return "";

        }

        const year = date.getFullYear();

        const month = String(

            date.getMonth() + 1

        ).padStart(2, "0");

        const day = String(

            date.getDate()

        ).padStart(2, "0");

        return `${year}-${month}-${day}`;

    }


    // Поточний локальний час

    function localTime(date = new Date()) {

        const hours = String(

            date.getHours()

        ).padStart(2, "0");

        const minutes = String(

            date.getMinutes()

        ).padStart(2, "0");

        return `${hours}:${minutes}`;

    }


    // Перевірка формату часу

    function isValidTime(value) {

        return typeof value === "string" &&

            /^([01]\d|2[0-3]):[0-5]\d$/.test(value);

    }


    // Перевірка формату календарної дати

    function isValidDate(value) {

        if (

            typeof value !== "string" ||

            !/^\d{4}-\d{2}-\d{2}$/.test(value)

        ) {

            return false;

        }

        return localDate(

            new Date(value + "T00:00:00")

        ) === value;

    }


    // ==============================================
    // 3. ОТРИМАННЯ ІСТОРІЇ СПОВІЩЕНЬ
    // ==============================================

    function loadState() {

        const saved = readStorage(STORAGE_KEY, {});

        return {

            // Усі повідомлення

            notifications: Array.isArray(
                saved?.notifications
            )

                ? saved.notifications.filter(item =>

                    item &&

                    typeof item === "object" &&

                    typeof item.id === "string"

                )

                : [],


            // Активні події для захисту від дублювання

            activeEvents:

                saved?.activeEvents &&

                typeof saved.activeEvents === "object" &&

                !Array.isArray(saved.activeEvents)

                    ? saved.activeEvents

                    : {}

        };

    }


    let state = loadState();


    // ==============================================
    // 4. ЗБЕРЕЖЕННЯ СПОВІЩЕНЬ
    // ==============================================

    function saveState() {

        try {

            sessionStorage.setItem(

                STORAGE_KEY,

                JSON.stringify(state)

            );

            storageError = false;

            return true;

        } catch (error) {

            storageError = true;

            console.error(

                "Cannot save notifications:",

                error

            );

            return false;

        }

    }


    // Повідомлення інших модулів про зміни

    function publishChanges() {

        saveState();

        renderNotifications();

        document.dispatchEvent(

            new CustomEvent(

                "pulsar:notifications-change",

                {

                    detail: {

                        unread: state.notifications.filter(

                            item => !item.read

                        ).length,

                        saved: !storageError

                    }

                }

            )

        );

    }


    // ==============================================
    // 5. ОТРИМАННЯ ДАНИХ ЕКІПАЖУ
    // ==============================================

    function getCrew() {

        // Спочатку використовуємо спільне сховище

        const saved = readStorage(

            CREW_STORAGE_KEY,

            null

        );

        if (Array.isArray(saved)) {

            return saved;

        }


        // Початкові дані головної сторінки

        if (

            typeof astronauts !== "undefined" &&

            Array.isArray(astronauts)

        ) {

            return astronauts;

        }

        return [];

    }


    // ==============================================
    // 6. СТВОРЕННЯ НОВОГО СПОВІЩЕННЯ
    // ==============================================

    function insertNotification(data) {

        if (

            !data ||

            typeof data !== "object" ||

            !data.title ||

            !data.message

        ) {

            return null;

        }


        // Категорія сповіщення

        const category = Object.hasOwn(

            priorities,

            data.category

        )

            ? data.category

            : "info";


        // Перевірка повторюваної події

        const dedupeKey = data.dedupeKey

            ? String(data.dedupeKey)

            : null;

        if (

            dedupeKey &&

            state.notifications.some(item =>

                item.dedupeKey === dedupeKey

            )

        ) {

            return null;

        }


        // Дата створення

        const date = data.timestamp != null

            ? new Date(data.timestamp)

            : new Date();

        const timestamp = Number.isFinite(date.getTime())

            ? date.toISOString()

            : new Date().toISOString();


        // Формування сповіщення

        const notification = {

            id: createId(),

            astronautId: data.astronautId ?? null,

            astronautName: String(

                data.astronautName || "Crew System"

            ),

            title: String(data.title),

            message: String(data.message),

            category,

            type: String(data.type || "general"),

            section: validSections.includes(data.section)

                ? data.section

                : "health",

            timestamp,

            read: false,

            readAt: null,

            dedupeKey

        };


        // Додаємо до історії

        state.notifications.unshift(notification);

        return notification;

    }


    // Публічна функція створення сповіщень

    function addNotification(data) {

        const notification = insertNotification(data);

        if (notification) {

            publishChanges();

        }

        return notification

            ? { ...notification }

            : null;

    }


    // ==============================================
    // 7. ЗАХИСТ ВІД ПОВТОРЮВАНИХ СПОВІЩЕНЬ
    // ==============================================

    function trackEvent(key, active, data, signature = "") {

        const previous = Object.hasOwn(

            state.activeEvents,

            key

        )

            ? state.activeEvents[key]

            : null;


        // Якщо умова більше не виконується,
        // подія перестає бути активною.
        // Історія сповіщень залишається.

        if (!active) {

            if (previous) {

                delete state.activeEvents[key];

                return true;

            }

            return false;

        }


        // Якщо така сама подія вже зафіксована

        if (

            previous &&

            previous.signature === signature

        ) {

            return false;

        }


        // Створюємо сповіщення про нову подію

        const notification = insertNotification(data);

        if (!notification) {

            return false;

        }


        // Запам'ятовуємо активну подію

        state.activeEvents[key] = {

            notificationId: notification.id,

            signature

        };

        return true;

    }


    // ==============================================
    // 8. ОТРИМАННЯ ВСІХ СПОВІЩЕНЬ
    // ==============================================

    function getNotifications() {

        return state.notifications.map(item => ({

            ...item

        }));

    }


    // ==============================================
    // 9. ПОЗНАЧЕННЯ ЯК ПРОЧИТАНОГО
    // ==============================================

    function markAsRead(id) {

        const notification = state.notifications.find(

            item => item.id === id

        );

        if (!notification || notification.read) {

            return false;

        }

        notification.read = true;

        notification.readAt = new Date().toISOString();

        publishChanges();

        return true;

    }


    // ==============================================
    // 10. ПРОЧИТАННЯ ВСІХ ПОВІДОМЛЕНЬ
    // ==============================================

    function markAllAsRead() {

        const timestamp = new Date().toISOString();

        let changed = false;

        state.notifications.forEach(item => {

            if (!item.read) {

                item.read = true;

                item.readAt = timestamp;

                changed = true;

            }

        });

        if (changed) {

            publishChanges();

        }

    }


    // ==============================================
    // 11. ПЕРЕВІРКА СТАНУ ЗДОРОВ'Я
    // ==============================================

    function syncHealth(person) {

        const preferences =

            person.settings?.notifications || {};

        const critical = person.status === "Critical";

        const warning =

            person.status === "Warning" &&

            preferences.health !== false;

        const message = String(

            person.warning || "Health status requires review."

        );

        let changed = false;


        // ==========================================
        // КРИТИЧНІ ПОПЕРЕДЖЕННЯ
        // НЕ ЗАЛЕЖАТЬ ВІД НАЛАШТУВАНЬ
        // ==========================================

        if (trackEvent(

            `health-critical:${person.id}`,

            critical,

            {

                astronautId: person.id,

                astronautName: person.name,

                title: "Critical Health Alert",

                message,

                category: "critical",

                type: "health-critical",

                section: "health"

            },

            message

        )) {

            changed = true;

        }


        // ==========================================
        // ЗВИЧАЙНІ ПОПЕРЕДЖЕННЯ
        // ==========================================

        if (trackEvent(

            `health-warning:${person.id}`,

            warning,

            {

                astronautId: person.id,

                astronautName: person.name,

                title: "Health Warning",

                message,

                category: "warning",

                type: "health-warning",

                section: "health"

            },

            message

        )) {

            changed = true;

        }

        return changed;

    }


    // ==============================================
    // 12. ПЕРЕВІРКА СТАНУ ПРИСТРОЮ
    // ==============================================

    function syncDevice(person) {

        const preferences =

            person.settings?.notifications || {};

        let changed = false;


        // Чи було раніше встановлено зв'язок

        const connectionKey =

            `device-connection:${person.id}`;

        const previousConnection =

            state.activeEvents[connectionKey]?.signature;


        // ==========================================
        // ВТРАТА АБО ВІДНОВЛЕННЯ ЗВ'ЯЗКУ
        // ==========================================

        if (typeof person.connected === "boolean") {

            const connection = person.connected

                ? "connected"

                : "disconnected";


            // Перший запис — лише фіксуємо стан.
            // Не повідомляємо про втрату зв'язку,
            // якщо пристрій ще не підключався.

            if (previousConnection !== connection) {

                if (

                    previousConnection &&

                    preferences.device !== false

                ) {

                    insertNotification({

                        astronautId: person.id,

                        astronautName: person.name,

                        title: person.connected

                            ? "Device Reconnected"

                            : "Device Connection Lost",

                        message: person.connected

                            ? "Connection to the wearable device has been restored."

                            : "Connection to the wearable device has been lost.",

                        category: "device",

                        type: person.connected

                            ? "device-reconnected"

                            : "device-disconnected",

                        section: "health"

                    });

                }

                state.activeEvents[connectionKey] = {

                    signature: connection

                };

                changed = true;

            }

        }


        // ==========================================
        // НИЗЬКИЙ ЗАРЯД БРАСЛЕТА
        // ==========================================

        const validBattery =

            Number.isFinite(person.battery) &&

            person.battery >= 0 &&

            person.battery <= 100;


        // Не аналізуємо невідомий або застарілий заряд

        if (person.connected === true && validBattery) {

            const lowBattery =

                person.battery <= LOW_BATTERY_THRESHOLD &&

                preferences.battery !== false;

            if (trackEvent(

                `battery:${person.id}`,

                lowBattery,

                {

                    astronautId: person.id,

                    astronautName: person.name,

                    title: "Device Battery Alert",

                    message:

                        `Wearable battery level is ${person.battery}%.` +

                        " Check device power availability.",

                    category: "device",

                    type: "battery-low",

                    section: "health"

                },

                "low-battery"

            )) {

                changed = true;

            }

        }

        return changed;

    }


    // ==============================================
    // 13. ПЕРЕВІРКА SOS
    // ==============================================

    function syncSos(person) {

        const records = readStorage(

            SOS_STORAGE_KEY,

            {}

        );

        const record = records?.[String(person.id)];

        const active = record?.active === true;


        // SOS не залежить від персональних налаштувань

        return trackEvent(

            `sos:${person.id}`,

            active,

            {

                astronautId: person.id,

                astronautName: person.name,

                title: "SOS Activated",

                message:

                    "Emergency assistance requested. " +

                    "Local demonstration signal only.",

                category: "critical",

                type: "sos",

                section: "health",

                timestamp: record?.timestamp

            },

            record?.timestamp || "active"

        );

    }


    // ==============================================
    // 14. ПЕРЕВІРКА AI HEALTH INSIGHTS
    // ==============================================

    function syncInsights(person, now = Date.now()) {

        // Перевіряємо наявність аналітичного модуля

        if (

            typeof window.PulsarInsights?.analyzeHealth

                !== "function"

        ) {

            return false;

        }

        const preferences =

            person.settings?.notifications || {};

        let analysis;

        try {

            // Аналізуємо лише історію профілю.
            // createDemoPerson тут не використовується.

            analysis = window.PulsarInsights.analyzeHealth(

                person,

                now

            );

        } catch (error) {

            console.error(

                "Cannot analyze health trends:",

                error

            );

            return false;

        }


        // Немає дозволу на додаткові попередження

        if (preferences.health === false) {

            return trackEvent(

                `insights:${person.id}`,

                false

            );

        }


        // Якщо даних недостатньо, не вважаємо,
        // що попередня проблема зникла.

        if (analysis.status === "Insufficient Data") {

            return false;

        }


        // Виявлені несприятливі тенденції

        const flagged = Array.isArray(analysis.flagged)

            ? analysis.flagged

            : [];

        const combined =

            analysis.status === "Attention Required";

        const early =

            analysis.status === "Early Changes";

        const active = combined || early;


        // Назви показників

        const names = flagged.map(

            item => item.name

        ).join(", ");


        // Підпис події.
        // Не створюємо нове повідомлення щохвилини,
        // якщо набір тенденцій залишається незмінним.

        const signature = analysis.status +

            ":" +

            flagged.map(item => item.key)

                .sort()

                .join(",");


        return trackEvent(

            `insights:${person.id}`,

            active,

            {

                astronautId: person.id,

                astronautName: person.name,

                title: combined

                    ? "Combined Health Trends Detected"

                    : "Early Health Trend Detected",

                message: names

                    ? "Indicators: " + names + ". " +

                        "Review historical measurements."

                    : "An unfavorable trend rule has been triggered.",

                category: "warning",

                type: "health-insights",

                section: "insights"

            },

            signature

        );

    }


    // ==============================================
    // 15. ЩОДЕННІ НАГАДУВАННЯ
    // ==============================================

    function syncReminders(person, now = new Date()) {

        const reminders =

            person.settings?.reminders || {};

        const today = localDate(now);

        const time = localTime(now);

        let changed = false;


        // ==========================================
        // DAILY CHECK-IN
        // ==========================================

        const checkinHistory = Array.isArray(

            person.checkinHistory

        )

            ? [...person.checkinHistory]

            : [];

        if (person.checkin) {

            checkinHistory.push(person.checkin);

        }


        // Перевіряємо, чи вже є запис за сьогодні

        const completedCheckin = checkinHistory.some(

            item => item?.date &&

                localDate(item.date) === today

        );


        // Нагадування після встановленого часу

        if (

            reminders.checkinEnabled === true &&

            isValidTime(reminders.checkinTime) &&

            time >= reminders.checkinTime &&

            !completedCheckin

        ) {

            const notification = insertNotification({

                astronautId: person.id,

                astronautName: person.name,

                title: "Daily Check-in Reminder",

                message:

                    "The scheduled daily well-being " +

                    "check-in is due.",

                category: "reminder",

                type: "checkin-reminder",

                section: "health",

                dedupeKey:

                    `checkin:${person.id}:${today}`

            });

            if (notification) {

                changed = true;

            }

        }


        // ==========================================
        // HEALTH MEASUREMENTS
        // ==========================================

        if (

            reminders.measurementEnabled === true &&

            isValidTime(reminders.measurementTime) &&

            time >= reminders.measurementTime

        ) {

            const notification = insertNotification({

                astronautId: person.id,

                astronautName: person.name,

                title: "Health Measurements Reminder",

                message:

                    "Scheduled additional health measurements " +

                    "are due. Follow the approved measurement plan.",

                category: "reminder",

                type: "measurement-reminder",

                section: "health",

                dedupeKey:

                    `measurement:${person.id}:${today}`

            });

            if (notification) {

                changed = true;

            }

        }

        return changed;

    }


    // ==============================================
    // 16. НАГАДУВАННЯ ПРО МЕДИЧНИЙ ОГЛЯД
    // ==============================================

    function syncMedicalExamination(

        person,

        now = new Date()

    ) {

        const nextExam =

            person.medicalCard?.assessment?.nextExam;

        const today = localDate(now);

        if (

            !isValidDate(nextExam) ||

            today < nextExam

        ) {

            return false;

        }


        // Одне сповіщення на заплановану дату огляду

        const notification = insertNotification({

            astronautId: person.id,

            astronautName: person.name,

            title: "Medical Examination Reminder",

            message:

                `Scheduled medical examination: ${nextExam}. ` +

                "Review the medical examination schedule.",

            category: "reminder",

            type: "medical-examination",

            section: "settings",

            dedupeKey:

                `medical-exam:${person.id}:${nextExam}`

        });

        return Boolean(notification);

    }


    // ==============================================
    // 17. ПЕРЕВІРКА ВСЬОГО ЕКІПАЖУ
    // ==============================================

    function syncCrew(people = getCrew()) {

        if (!Array.isArray(people)) {

            return;

        }

        let changed = false;

        const now = new Date();


        // Перевіряємо кожного астронавта

        people.forEach(person => {

            if (

                !person ||

                person.id == null

            ) {

                return;

            }


            // Стан здоров'я

            if (syncHealth(person)) {

                changed = true;

            }


            // Стан пристроїв

            if (syncDevice(person)) {

                changed = true;

            }


            // SOS

            if (syncSos(person)) {

                changed = true;

            }


            // Ранні тенденції

            if (syncInsights(person, now.getTime())) {

                changed = true;

            }


            // Нагадування

            if (syncReminders(person, now)) {

                changed = true;

            }


            // Медичний огляд

            if (syncMedicalExamination(person, now)) {

                changed = true;

            }

        });


        // Оновлюємо сховище та інтерфейс

        if (changed) {

            publishChanges();

        } else {

            renderNotifications();

        }

    }


    // ==============================================
    // 18. ФОРМАТУВАННЯ ЧАСУ
    // ==============================================

    function formatNotificationTime(timestamp) {

        const date = new Date(timestamp);

        if (!Number.isFinite(date.getTime())) {

            return "Time unavailable";

        }

        const elapsed = Math.max(

            0,

            Date.now() - date.getTime()

        );

        const minutes = Math.floor(

            elapsed / 60000

        );

        if (minutes < 1) {

            return "Just now";

        }

        if (minutes < 60) {

            return minutes === 1

                ? "1 minute ago"

                : `${minutes} minutes ago`;

        }

        const hours = Math.floor(minutes / 60);

        if (hours < 24) {

            return hours === 1

                ? "1 hour ago"

                : `${hours} hours ago`;

        }

        const days = Math.floor(hours / 24);

        if (days < 7) {

            return days === 1

                ? "1 day ago"

                : `${days} days ago`;

        }

        return date.toLocaleString("en-GB", {

            day: "2-digit",

            month: "short",

            year: "numeric",

            hour: "2-digit",

            minute: "2-digit"

        });

    }


    // ==============================================
    // 19. ІКОНКИ СПОВІЩЕНЬ
    // ==============================================

    function getNotificationIcon(type) {

        const icons = {

            "health-critical": "!",

            "health-warning": "♡",

            "health-insights": "✧",

            "sos": "SOS",

            "battery-low": "▱",

            "device-disconnected": "◎",

            "device-reconnected": "✓",

            "checkin-reminder": "◷",

            "measurement-reminder": "▥",

            "medical-examination": "✚",

            "general": "ⓘ"

        };

        return Object.hasOwn(icons, type)

            ? icons[type]

            : "ⓘ";

    }


    // ==============================================
    // 20. ФІЛЬТРАЦІЯ СПОВІЩЕНЬ
    // ==============================================

    function getFilteredNotifications() {

        let items = [...state.notifications];


        // Усі сповіщення

        if (currentFilter === "all") {

            // Залишаємо весь список

        }


        // Непрочитані

        else if (currentFilter === "unread") {

            items = items.filter(item =>

                !item.read

            );

        }


        // За категорією

        else {

            items = items.filter(item =>

                item.category === currentFilter

            );

        }


        // Сортування: критичні непрочитані першими,
        // далі інші непрочитані,
        // потім прочитані повідомлення.

        return items.sort((a, b) => {

            if (a.read !== b.read) {

                return Number(a.read) -

                    Number(b.read);

            }

            const priorityDifference =

                (priorities[a.category] ?? 4) -

                (priorities[b.category] ?? 4);

            if (priorityDifference !== 0) {

                return priorityDifference;

            }

            return (

                Date.parse(b.timestamp) || 0

            ) - (

                Date.parse(a.timestamp) || 0

            );

        });

    }


    // ==============================================
    // 21. СТВОРЕННЯ КАРТКИ СПОВІЩЕННЯ
    // ==============================================

    function createNotificationCard(item) {

        const category = Object.hasOwn(

            priorities,

            item.category

        )

            ? item.category

            : "info";

        const categoryName = {

            critical: "Critical",

            warning: "Warning",

            device: "Device",

            reminder: "Reminder",

            info: "Information"

        }[category];


        return `

            <article class="notification-item
                ${category}
                ${item.read ? "is-read" : "is-unread"}">


                <!-- ІКОНКА -->

                <div class="notification-item-icon"
                     aria-hidden="true">

                    ${escapeHTML(

                        getNotificationIcon(item.type)

                    )}

                </div>


                <!-- ОСНОВНА ІНФОРМАЦІЯ -->

                <div class="notification-item-content">


                    <!-- КАТЕГОРІЯ -->

                    <div class="notification-item-top">

                        <span class="notification-category">

                            ${categoryName}

                        </span>

                        ${!item.read ? `

                            <span class="notification-unread-dot"
                                  aria-label="Unread">

                            </span>

                        ` : ""}

                    </div>


                    <!-- ЗАГОЛОВОК -->

                    <h4>

                        ${escapeHTML(item.title)}

                    </h4>


                    <!-- ІМ'Я АСТРОНАВТА -->

                    <strong class="notification-person">

                        ${escapeHTML(item.astronautName)}

                    </strong>


                    <!-- ПОВІДОМЛЕННЯ -->

                    <p class="notification-message">

                        ${escapeHTML(item.message)}

                    </p>


                    <!-- ЧАС -->

                    <time
                        class="notification-time"
                        datetime="${escapeHTML(item.timestamp)}">

                        ${escapeHTML(

                            formatNotificationTime(

                                item.timestamp

                            )

                        )}

                    </time>


                    <!-- ДІЇ -->

                    <div class="notification-item-actions">


                        ${item.astronautId != null ? `

                            <button
                                type="button"
                                class="notification-view-button"
                                data-notification-action="view"
                                data-notification-id="${escapeHTML(item.id)}">

                                View Details →

                            </button>

                        ` : ""}


                        ${!item.read ? `

                            <button
                                type="button"
                                class="notification-read-button"
                                data-notification-action="read"
                                data-notification-id="${escapeHTML(item.id)}">

                                ✓ Mark as read

                            </button>

                        ` : `

                            <span class="notification-read-label">

                                ✓ Read

                            </span>

                        `}

                    </div>

                </div>

            </article>

        `;

    }


    // ==============================================
    // 22. ОНОВЛЕННЯ ЛІЧИЛЬНИКІВ
    // ==============================================

    function updateCounters() {

        const all = state.notifications;

        const unread = all.filter(

            item => !item.read

        ).length;


        // Усі критичні повідомлення в історії,
        // включно з прочитаними.

        const critical = all.filter(

            item => item.category === "critical"

        ).length;


        // Кількість на дзвіночку

        const badge = document.getElementById(

            "notification-badge"

        );

        if (badge) {

            badge.hidden = unread === 0;

            badge.textContent = unread > 99

                ? "99+"

                : String(unread);

        }


        // Допоміжна функція оновлення тексту

        function setText(id, value) {

            const element = document.getElementById(id);

            if (element) {

                element.textContent = value;

            }

        }


        setText(

            "notification-total",

            all.length

        );

        setText(

            "notification-unread",

            unread

        );

        setText(

            "notification-critical",

            critical

        );

        setText(

            "notification-unread-count",

            unread === 1

                ? "1 unread notification"

                : `${unread} unread notifications`

        );


        // Доступність кнопки дзвіночка

        const toggle = document.getElementById(

            "notification-toggle"

        );

        if (toggle) {

            toggle.setAttribute(

                "aria-label",

                `Notifications, ${unread} unread`

            );

        }


        // Кнопка прочитання всіх

        const markAll = document.getElementById(

            "notification-mark-all"

        );

        if (markAll) {

            markAll.disabled = unread === 0;

        }


        // Повідомлення про помилку збереження

        const footer = document.querySelector(

            ".notification-footer > span:first-child"

        );

        if (footer) {

            footer.textContent = storageError

                ? "Demo storage unavailable"

                : "Crew Notification Center";

        }

    }


    // ==============================================
    // 23. ВІДОБРАЖЕННЯ ЦЕНТРУ СПОВІЩЕНЬ
    // ==============================================

    function renderNotifications() {

        updateCounters();

        const list = document.getElementById(

            "notification-list"

        );

        if (!list) {

            return;

        }


        // Активний фільтр

        document.querySelectorAll(

            ".notification-filter"

        ).forEach(button => {

            const active =

                button.dataset.notificationFilter ===

                currentFilter;

            button.classList.toggle(

                "active",

                active

            );

            button.setAttribute(

                "aria-pressed",

                String(active)

            );

        });


        // Отримуємо відфільтрований список

        const notifications =

            getFilteredNotifications();


        // Якщо повідомлень немає

        if (!notifications.length) {

            const message = currentFilter === "unread"

                ? "You have no unread notifications."

                : "No notifications match this filter.";

            list.innerHTML = `

                <div class="notification-empty">

                    <span aria-hidden="true">

                        ✓

                    </span>

                    <h4>No notifications</h4>

                    <p>${escapeHTML(message)}</p>

                </div>

            `;

            return;

        }


        // Зберігаємо позицію прокручування

        const scrollPosition = list.scrollTop;


        // Відображаємо картки

        list.innerHTML = notifications.map(

            createNotificationCard

        ).join("");


        // Відновлюємо позицію

        list.scrollTop = scrollPosition;

    }


    // ==============================================
    // 24. ВІДКРИТТЯ ПАНЕЛІ
    // ==============================================

    function openPanel() {

        const panel = document.getElementById(

            "notification-panel"

        );

        const toggle = document.getElementById(

            "notification-toggle"

        );

        if (!panel || !toggle) {

            return;

        }


        // Закриваємо інші випадаючі панелі

        [

            ["crew-menu", "menu-toggle"],

            ["search-panel", "search-toggle"]

        ].forEach(([panelId, buttonId]) => {

            const otherPanel =

                document.getElementById(panelId);

            const otherButton =

                document.getElementById(buttonId);

            if (otherPanel && !otherPanel.hidden) {

                if (otherButton) {

                    otherButton.click();

                }

            }

        });


        // Перевіряємо нові події

        syncCrew();


        // Відкриваємо Notification Center

        panel.hidden = false;

        toggle.setAttribute(

            "aria-expanded",

            "true"

        );

        toggle.classList.add("active");

    }


    // ==============================================
    // 25. ЗАКРИТТЯ ПАНЕЛІ
    // ==============================================

    function closePanel(restoreFocus = false) {

        const panel = document.getElementById(

            "notification-panel"

        );

        const toggle = document.getElementById(

            "notification-toggle"

        );

        if (!panel || !toggle) {

            return;

        }

        panel.hidden = true;

        toggle.setAttribute(

            "aria-expanded",

            "false"

        );

        toggle.classList.remove("active");

        if (restoreFocus) {

            toggle.focus();

        }

    }


    // ==============================================
    // 26. ПЕРЕХІД ДО ПРОФІЛЮ АСТРОНАВТА
    // ==============================================

    function openNotification(id) {

        const item = state.notifications.find(

            notification => notification.id === id

        );

        if (!item || item.astronautId == null) {

            return;

        }


        // Якщо астронавт відсутній у поточному екіпажі

        const person = getCrew().find(

            astronaut =>

                String(astronaut.id) ===

                String(item.astronautId)

        );

        if (!person) {

            alert("Astronaut profile is unavailable.");

            return;

        }


        // Зберігаємо дані перед переходом

        if (typeof saveCrew === "function") {

            if (!saveCrew()) {

                alert("Demo crew storage is unavailable.");

                return;

            }

        } else {

            try {

                sessionStorage.setItem(

                    CREW_STORAGE_KEY,

                    JSON.stringify(getCrew())

                );

            } catch (error) {

                alert("Demo crew storage is unavailable.");

                return;

            }

        }


        // Визначаємо розділ профілю

        const section = validSections.includes(

            item.section

        )

            ? item.section

            : "health";


        // Позначаємо повідомлення як прочитане

        markAsRead(id);


        // Визначаємо правильний шлях

        const insidePages =

            window.location.pathname.endsWith(

                "/pages/astronaut.html"

            );

        const profilePath = insidePages

            ? "astronaut.html"

            : "pages/astronaut.html";


        // Формуємо адресу профілю

        const url = new URL(

            profilePath,

            window.location.href

        );

        url.searchParams.set(

            "id",

            person.id

        );

        url.searchParams.set(

            "section",

            section

        );


        // Переходимо до профілю

        window.location.href = url.href;

    }


    // ==============================================
    // 27. ОБРОБНИКИ ПОДІЙ
    // ==============================================

    function initializeUI() {

        if (uiInitialized) {

            return;

        }

        const toggle = document.getElementById(

            "notification-toggle"

        );

        const panel = document.getElementById(

            "notification-panel"

        );

        const close = document.getElementById(

            "notification-close"

        );

        const list = document.getElementById(

            "notification-list"

        );

        const markAll = document.getElementById(

            "notification-mark-all"

        );

        if (!toggle || !panel || !list) {

            return;

        }

        uiInitialized = true;


        // ==========================================
        // НАТИСКАННЯ НА ДЗВІНОЧОК
        // ==========================================

        toggle.addEventListener("click", () => {

            if (panel.hidden) {

                openPanel();

            } else {

                closePanel();

            }

        });


        // ==========================================
        // КНОПКА ЗАКРИТТЯ
        // ==========================================

        close?.addEventListener("click", () => {

            closePanel(true);

        });


        // ==========================================
        // ФІЛЬТРИ
        // ==========================================

        document.querySelectorAll(

            ".notification-filter"

        ).forEach(button => {

            button.addEventListener("click", () => {

                currentFilter =

                    button.dataset.notificationFilter;

                list.scrollTop = 0;

                renderNotifications();

            });

        });


        // ==========================================
        // ПРОЧИТАТИ ВСІ
        // ==========================================

        markAll?.addEventListener(

            "click",

            markAllAsRead

        );


        // ==========================================
        // ДІЇ ВСЕРЕДИНІ СПИСКУ
        // ==========================================

        list.addEventListener("click", event => {

            const button = event.target.closest(

                "[data-notification-action]"

            );

            if (!button || !list.contains(button)) {

                return;

            }

            const id =

                button.dataset.notificationId;

            const action =

                button.dataset.notificationAction;

            if (action === "read") {

                markAsRead(id);

            }

            if (action === "view") {

                openNotification(id);

            }

        });


        // ==========================================
        // ЗАКРИТТЯ ПРИ НАТИСКАННІ ПОЗА ПАНЕЛЛЮ
        // ==========================================

        document.addEventListener("click", event => {

            if (

                !panel.hidden &&

                !panel.contains(event.target) &&

                !toggle.contains(event.target)

            ) {

                closePanel();

            }

        });


        // ==========================================
        // ЗАКРИТТЯ КЛАВІШЕЮ ESCAPE
        // ==========================================

        document.addEventListener("keydown", event => {

            if (

                event.key === "Escape" &&

                !panel.hidden

            ) {

                closePanel(true);

            }

        });

    }


    // ==============================================
    // 28. АВТОМАТИЧНЕ ОНОВЛЕННЯ
    // ==============================================

    // Подія активації або скасування SOS

    document.addEventListener(

        "pulsar:sos-change",

        () => {

            syncCrew();

        }

    );


    // Подія оновлення даних екіпажу.
    // Використовуватимемо після інтеграції модулів.

    document.addEventListener(

        "pulsar:crew-change",

        event => {

            const people = event.detail?.crew;

            syncCrew(

                Array.isArray(people)

                    ? people

                    : getCrew()

            );

        }

    );


    // Оновлення після повернення через Back

    window.addEventListener("pageshow", () => {

        if (!storageError) {

            state = loadState();

        }

        syncCrew();

    });


    // Оновлення при поверненні до вкладки

    document.addEventListener(

        "visibilitychange",

        () => {

            if (document.visibilityState === "visible") {

                syncCrew();

            }

        }

    );


    // ==============================================
    // 29. ПІДКЛЮЧЕННЯ ДО ІНШИХ МОДУЛІВ
    // ==============================================

    window.PulsarNotifications = Object.freeze({

        addNotification,

        getNotifications,

        markAsRead,

        markAllAsRead,

        syncCrew,

        renderNotifications,

        openPanel,

        closePanel

    });


    // ==============================================
    // 30. ПОЧАТКОВИЙ ЗАПУСК
    // ==============================================

    function initialize() {

        initializeUI();

        syncCrew();


        // Перевіряємо події раз на хвилину,
        // поки сторінка відкрита.
        // Це не фонова серверна система.

        window.setInterval(() => {

            if (document.visibilityState === "visible") {

                syncCrew();

            }

        }, CHECK_INTERVAL);

    }


    // Очікуємо завантаження HTML та інших скриптів

    if (document.readyState === "loading") {

        document.addEventListener(

            "DOMContentLoaded",

            initialize,

            { once: true }

        );

    } else {

        initialize();

    }

})();
